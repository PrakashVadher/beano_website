var fb;
var container;

function setCookie(cname, cvalue, exdays) {
    var d = new Date();
    d.setTime(d.getTime() + (exdays*24*60*60*1000));
    var expires = "expires="+ d.toUTCString();
    document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
}

function getCookie(cname) {
    var name = cname + "=";
    var decodedCookie = decodeURIComponent(document.cookie);
    var ca = decodedCookie.split(';');
    for(var i = 0; i <ca.length; i++) {
      var c = ca[i];
      while (c.charAt(0) == ' ') {
        c = c.substring(1);
      }
      if (c.indexOf(name) == 0) {
        return c.substring(name.length, c.length);
      }
    }
    return "";
  }

function delete_cookie(cname) {
    document.cookie = cname + "= ; expires = Thu, 01 Jan 1970 00:00:00 GMT; path=/";
}


jQuery(document).ready(function() {

    //allow only numeric input >=0 in payment fields
    jQuery(document).on("click", ".selection > input", function(){
        jQuery(this).inputFilter(function(value) {
            return /^\d*$/.test(value); });
    });

    //Build form page tabs
    jQuery('div.easypayblock ul#tabs-list li').click(function(){
        var id = jQuery(this).data('id');
        setCookie('wpep-setting-tab', id, 365);
    });


    // global settings
    if (getCookie('wpep-payment-mode')) {
        jQuery("#on-off").attr('checked', true);
        jQuery(".wp-easy-pay_page_wpep-settings #wpep_spmgt").removeClass('testActive');
        jQuery(".wp-easy-pay_page_wpep-settings #wpep_spmgl").addClass('liveActive');
    }else{
        jQuery("#on-off").attr('checked', false);
        jQuery(".wp-easy-pay_page_wpep-settings #wpep_spmgt").addClass('testActive');
        jQuery(".wp-easy-pay_page_wpep-settings #wpep_spmgl").removeClass('liveActive');
    }

    jQuery("#on-off").click(function () {
        
        if (jQuery(this).is(":checked")) {
            jQuery(".wp-easy-pay_page_wpep-settings #wpep_spmgt").removeClass('testActive');
            jQuery(".wp-easy-pay_page_wpep-settings #wpep_spmgl").addClass('liveActive');
            setCookie('wpep-payment-mode', 'live', 365);
        } else {
            jQuery(".wp-easy-pay_page_wpep-settings #wpep_spmgt").addClass('testActive');
            jQuery(".wp-easy-pay_page_wpep-settings #wpep_spmgl").removeClass('liveActive');
            delete_cookie('wpep-payment-mode');
        }
        jQuery('form.wpeasyPay-form').submit();
    });

    if (jQuery('#donation').is(":checked")) {

        jQuery("#donation-dependedt").show();

    } else {

        jQuery("#donation-dependedt").hide();
    }
});