if(jQuery(".activate-license").length) {

    jQuery('.activate-license').each(function(index, item){

        if (jQuery(this).hasClass('wp-easy-pay')){
            jQuery(this).css('display', 'none');
        }

    });

}